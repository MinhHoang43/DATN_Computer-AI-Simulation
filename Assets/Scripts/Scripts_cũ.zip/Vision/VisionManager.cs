using System.Collections;
using System.Diagnostics;
using UnityEngine;

public class VisionManager : MonoBehaviour
{
    public static VisionManager Instance;

    [Header("Inspection")]
    public Transform inspectionPoint;
    public float stopDistance = 0.05f;

    [Header("Timing")]
    public float settleTime = 0.5f;
    public float inspectionTime = 1.5f;

    [Header("Capture")]
    public CameraCapture cameraCapture;

    private bool isInspecting = false;

    private void Awake()
    {
        Instance = this;
    }

    public bool StartInspection(PCBMove pcb)
    {
        if (isInspecting || pcb == null)
            return false;

        StartCoroutine(ProcessPCB(pcb));
        return true;
    }

    private IEnumerator ProcessPCB(PCBMove pcb)
    {
        isInspecting = true;

        pcb.StopMove();
        UnityEngine.Debug.Log("PCB dừng tại vị trí kiểm tra.");

        yield return new WaitForSeconds(settleTime);

        Texture2D image = null;

        if (cameraCapture != null)
        {
            image = cameraCapture.Capture();
            UnityEngine.Debug.Log("Camera đã chụp ảnh PCB.");
        }
        else
        {
            UnityEngine.Debug.LogWarning("VisionManager thiếu CameraCapture.");
        }

        if (image != null && PCBYOLOManager.Instance != null)
        {
            PCBInfo info = pcb.GetComponent<PCBInfo>();

            Stopwatch sw = Stopwatch.StartNew();

            var detections = PCBYOLOManager.Instance.Detect(image);

            sw.Stop();

            float inferenceTimeMs = sw.ElapsedMilliseconds;

            Texture2D displayImage = image;

            if (detections.Count > 0)
            {
                displayImage = BoundingBoxRenderer.DrawBoxes(image, detections);
            }

            if (CameraPreviewUI.Instance != null)
            {
                CameraPreviewUI.Instance.ShowImage(displayImage);
                CameraPreviewUI.Instance.ShowResult(detections, inferenceTimeMs);
            }

            //---------------------------------
            // Lưu kết quả vào PCBInfo
            //---------------------------------

            if (detections.Count == 0)
            {
                if (info != null)
                {
                    info.inspected = true;
                    info.isNG = false;
                    info.defectClass = "OK";
                    info.confidence = 1f;

                    UnityEngine.Debug.Log("PCBInfo -> OK");
                }

                UnityEngine.Debug.Log("Kết quả YOLO: OK");
            }
            else
            {
                if (info != null)
                {
                    info.inspected = true;
                    info.isNG = true;
                    info.defectClass = detections[0].className;
                    info.confidence = detections[0].confidence;

                    UnityEngine.Debug.Log(
                        "PCBInfo -> " +
                        info.defectClass +
                        " | Conf = " +
                        info.confidence.ToString("F2")
                    );
                }

                UnityEngine.Debug.Log("Kết quả YOLO: NG");

                foreach (var d in detections)
                {
                    UnityEngine.Debug.Log(
                        d.className +
                        " | Conf: " +
                        (d.confidence * 100f).ToString("F1") +
                        "%" +
                        " | Box: " +
                        d.box
                    );
                }
            }
        }
        else
        {
            UnityEngine.Debug.LogWarning("Không thể chạy YOLO.");
        }

        yield return new WaitForSeconds(inspectionTime);

        pcb.MarkInspected();
        pcb.ResumeMove();

        UnityEngine.Debug.Log("PCB kiểm tra xong, chạy tiếp.");

        isInspecting = false;
    }
}