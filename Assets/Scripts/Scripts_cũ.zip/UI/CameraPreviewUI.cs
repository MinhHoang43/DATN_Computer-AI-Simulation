using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class CameraPreviewUI : MonoBehaviour
{
    public static CameraPreviewUI Instance;

    [Header("UI")]
    public RawImage cameraImage;

    [Header("Texts")]
    public TextMeshProUGUI statusText;
    public TextMeshProUGUI infoText;

    private void Awake()
    {
        Instance = this;
    }

    public void ShowImage(Texture2D image)
    {
        if (cameraImage == null || image == null)
            return;

        cameraImage.texture = image;
    }

    public void ShowWaiting()
    {
        if (statusText != null)
        {
            statusText.text = "Status : Waiting...";
            statusText.color = Color.white;
        }

        if (infoText != null)
        {
            infoText.text =
                "Class : -\n" +
                "Confidence : -\n" +
                "Objects : -\n" +
                "Time : -";
        }
    }

    public void ShowResult(List<PCBYOLOManager.Detection> detections, float inferenceTimeMs)
    {
        if (detections == null)
            return;

        if (detections.Count == 0)
        {
            if (statusText != null)
            {
                statusText.text = "Status : OK";
                statusText.color = Color.green;
            }

            if (infoText != null)
            {
                infoText.text =
                    "Class : OK\n" +
                    "Confidence : -\n" +
                    "Objects : 0\n" +
                    "Time : " + inferenceTimeMs.ToString("F1") + " ms";
            }
        }
        else
        {
            PCBYOLOManager.Detection d = detections[0];

            if (statusText != null)
            {
                statusText.text = "Status : NG";
                statusText.color = Color.red;
            }

            if (infoText != null)
            {
                infoText.text =
                    "Class : " + d.className + "\n" +
                    "Confidence : " + (d.confidence * 100f).ToString("F1") + " %\n" +
                    "Objects : " + detections.Count + "\n" +
                    "Time : " + inferenceTimeMs.ToString("F1") + " ms";
            }
        }
    }
}