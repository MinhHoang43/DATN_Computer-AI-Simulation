using UnityEngine;

public class PCBTextureDatabase : MonoBehaviour
{
    public static PCBTextureDatabase Instance;

    [Header("Loaded PCB Textures")]
    public Texture2D[] allTextures;

    private void Awake()
    {
        Instance = this;

        allTextures = Resources.LoadAll<Texture2D>("PCBImages");

        Debug.Log("Loaded PCB textures: " + allTextures.Length);
    }

    public Texture2D GetRandomTexture()
    {
        if (allTextures == null || allTextures.Length == 0)
        {
            Debug.LogWarning("Không tìm thấy ảnh PCB trong Resources/PCBImages.");
            return null;
        }

        int index = Random.Range(0, allTextures.Length);
        return allTextures[index];
    }
}