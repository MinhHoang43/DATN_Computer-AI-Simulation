using UnityEngine;

public class PCBInfo : MonoBehaviour
{
    [Header("Inspection Result")]
    public bool inspected = false;
    public bool isNG = false;

    [Tooltip("Prediction result returned by YOLO.")]
    public string defectClass = "OK";

    [Range(0, 1)]
    public float confidence = 0f;

    [Header("Ground Truth Evaluation")]
    [Tooltip("True class of this PCB, assigned when the PCB is spawned from a Resources folder.")]
    public string groundTruth = "Unknown";

    [Tooltip("True after YOLO prediction has been compared with Ground Truth.")]
    public bool evaluated = false;

    [Tooltip("True if Ground Truth and YOLO prediction match.")]
    public bool isCorrect = false;

    public void SetGroundTruth(string className)
    {
        groundTruth = string.IsNullOrWhiteSpace(className) ? "Unknown" : className.Trim();
        evaluated = false;
        isCorrect = false;
    }

    public void EvaluatePrediction()
    {
        evaluated = true;
        isCorrect = NormalizeClassName(groundTruth) == NormalizeClassName(defectClass);
    }

    public static string NormalizeClassName(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return "";

        return value
            .Trim()
            .ToLowerInvariant()
            .Replace("_", " ")
            .Replace("-", " ")
            .Replace("  ", " ");
    }
}
