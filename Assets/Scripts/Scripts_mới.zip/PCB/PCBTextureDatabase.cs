using System.Collections.Generic;
using UnityEngine;

public class PCBTextureDatabase : MonoBehaviour
{
    public static PCBTextureDatabase Instance;

    [Header("Resources Settings")]
    [Tooltip("Root folder inside Assets/Resources.")]
    public string resourcesRoot = "PCBImages";

    [Tooltip("Folder names under Resources/PCBImages. These names are used as Ground Truth class names.")]
    public string[] classFolders =
    {
        "OK",
        "Missing USB",
        "Missing CP2102",
        "Missing ESP32",
        "Missing Capacitor",
        "Missing Resistor"
    };

    [Header("Loaded PCB Textures")]
    public Texture2D[] allTextures;

    private readonly Dictionary<Texture2D, string> textureToClass =
        new Dictionary<Texture2D, string>();

    private void Awake()
    {
        Instance = this;
        LoadTextures();
    }

    private void LoadTextures()
    {
        textureToClass.Clear();

        List<Texture2D> loadedTextures = new List<Texture2D>();

        foreach (string className in classFolders)
        {
            if (string.IsNullOrWhiteSpace(className))
                continue;

            string folderPath = resourcesRoot + "/" + className.Trim();
            Texture2D[] texturesInClass = Resources.LoadAll<Texture2D>(folderPath);

            foreach (Texture2D texture in texturesInClass)
            {
                if (texture == null)
                    continue;

                loadedTextures.Add(texture);

                if (!textureToClass.ContainsKey(texture))
                    textureToClass.Add(texture, className.Trim());
            }

            Debug.Log(
                "Loaded " +
                texturesInClass.Length +
                " PCB textures for class: " +
                className.Trim()
            );
        }

        allTextures = loadedTextures.ToArray();

        Debug.Log("Loaded PCB textures total: " + allTextures.Length);

        if (allTextures.Length == 0)
        {
            Debug.LogWarning(
                "Không tìm thấy ảnh PCB. Kiểm tra lại thư mục: Assets/Resources/" +
                resourcesRoot +
                "/<ClassName>"
            );
        }
    }

    public Texture2D GetRandomTexture()
    {
        if (allTextures == null || allTextures.Length == 0)
        {
            Debug.LogWarning("Không tìm thấy ảnh PCB trong Resources/" + resourcesRoot + ".");
            return null;
        }

        int index = Random.Range(0, allTextures.Length);
        return allTextures[index];
    }

    public string GetClassName(Texture2D texture)
    {
        if (texture == null)
            return "Unknown";

        if (textureToClass.TryGetValue(texture, out string className))
            return className;

        return "Unknown";
    }
}
