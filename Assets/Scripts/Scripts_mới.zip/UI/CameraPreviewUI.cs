using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class CameraPreviewUI : MonoBehaviour
{
    public static CameraPreviewUI Instance;

    [Header("UI")]
    public RawImage cameraImage;

    [Header("Texts")]
    public TextMeshProUGUI statusText;
    public TextMeshProUGUI infoText;

    private int totalCount = 0;
    private int correctCount = 0;
    private int wrongCount = 0;

    private void Awake()
    {
        Instance = this;
    }

    public void ShowImage(Texture2D image)
    {
        if (cameraImage == null || image == null)
            return;

        cameraImage.texture = image;
    }

    public void ShowWaiting()
    {
        if (statusText != null)
        {
            statusText.text = "Status : Waiting...";
            statusText.color = Color.white;
        }

        if (infoText != null)
        {
            infoText.text =
                "Ground Truth : -\n" +
                "Prediction : -\n" +
                "Confidence : -\n" +
                "Objects : -\n" +
                "Time : -\n" +
                "Correct : -\n\n" +
                "Total : " + totalCount + "\n" +
                "Correct : " + correctCount + "\n" +
                "Wrong : " + wrongCount + "\n" +
                "Accuracy : " + GetAccuracyText();
        }
    }

    public void ShowResult(List<PCBYOLOManager.Detection> detections, float inferenceTimeMs)
    {
        ShowResult(detections, inferenceTimeMs, null);
    }

    public void ShowResult(
        List<PCBYOLOManager.Detection> detections,
        float inferenceTimeMs,
        PCBInfo pcbInfo
    )
    {
        if (detections == null)
            return;

        string prediction = "OK";
        float confidence = 1f;
        int objectCount = detections.Count;

        if (detections.Count > 0)
        {
            PCBYOLOManager.Detection d = detections[0];
            prediction = d.className;
            confidence = d.confidence;
        }

        if (pcbInfo != null && pcbInfo.evaluated)
        {
            totalCount++;

            if (pcbInfo.isCorrect)
                correctCount++;
            else
                wrongCount++;
        }

        bool isOK = prediction == "OK";
        bool? correct = null;

        if (pcbInfo != null && pcbInfo.evaluated)
            correct = pcbInfo.isCorrect;

        if (statusText != null)
        {
            if (correct.HasValue)
            {
                statusText.text = correct.Value ? "Status : CORRECT" : "Status : WRONG";
                statusText.color = correct.Value ? Color.green : Color.red;
            }
            else
            {
                statusText.text = isOK ? "Status : OK" : "Status : NG";
                statusText.color = isOK ? Color.green : Color.red;
            }
        }

        if (infoText != null)
        {
            string groundTruth =
                pcbInfo != null && !string.IsNullOrWhiteSpace(pcbInfo.groundTruth)
                    ? pcbInfo.groundTruth
                    : "-";

            string correctText = "-";

            if (correct.HasValue)
                correctText = correct.Value ? "Correct" : "Wrong";

            infoText.text =
                "Ground Truth : " + groundTruth + "\n" +
                "Prediction : " + prediction + "\n" +
                "Confidence : " + (confidence * 100f).ToString("F1") + " %\n" +
                "Objects : " + objectCount + "\n" +
                "Time : " + inferenceTimeMs.ToString("F1") + " ms\n" +
                "Result : " + correctText + "\n\n" +
                "Total : " + totalCount + "\n" +
                "Correct : " + correctCount + "\n" +
                "Wrong : " + wrongCount + "\n" +
                "Accuracy : " + GetAccuracyText();
        }
    }

    private string GetAccuracyText()
    {
        if (totalCount <= 0)
            return "-";

        float accuracy = (float)correctCount / totalCount * 100f;
        return accuracy.ToString("F2") + " %";
    }

    public void ResetStatistics()
    {
        totalCount = 0;
        correctCount = 0;
        wrongCount = 0;
        ShowWaiting();
    }
}
