using UnityEngine;

public class PCBInfo : MonoBehaviour
{
    [Header("Inspection Result")]

    public bool inspected = false;

    public bool isNG = false;

    public string defectClass = "OK";

    [Range(0, 1)]
    public float confidence = 0f;
}