using UnityEngine;

public class PCBSorter : MonoBehaviour
{
    [Header("Sorting")]
    public bool isSorting = false;
    public Vector3 targetPosition;
    public float sortingSpeed = 1.2f;

    public void StartSorting(Vector3 target)
    {
        targetPosition = target;
        isSorting = true;
    }

    void Update()
    {
        if (!isSorting)
            return;

        transform.position = Vector3.MoveTowards(
            transform.position,
            targetPosition,
            sortingSpeed * Time.deltaTime
        );

        if (Vector3.Distance(transform.position, targetPosition) < 0.03f)
        {
            Destroy(gameObject);
        }
    }
}