using UnityEngine;

public class SortingManager : MonoBehaviour
{
    public static SortingManager Instance;

    [Header("Sorting Point")]
    public Transform sortingPoint;
    public float triggerDistance = 0.1f;

    [Header("Target Boxes")]
    public Transform boxOK;
    public Transform boxUSB;
    public Transform boxCP2102;
    public Transform boxESP32;
    public Transform boxCapacitor;
    public Transform boxResistor;

    private void Awake()
    {
        Instance = this;
    }

    public void CheckSorting(PCBMove pcbMove)
    {
        if (pcbMove == null)
            return;

        PCBInfo info = pcbMove.GetComponent<PCBInfo>();
        PCBSorter sorter = pcbMove.GetComponent<PCBSorter>();

        if (info == null || sorter == null)
            return;

        if (!info.inspected)
            return;

        float distance = Mathf.Abs(
            pcbMove.transform.position.x - sortingPoint.position.x
        );

        if (distance > triggerDistance)
            return;

        Vector3 target = GetTargetPosition(info.defectClass);

        pcbMove.StopMove();
        sorter.StartSorting(target);

        Debug.Log("Sorting PCB -> " + info.defectClass);
    }

    Vector3 GetTargetPosition(string defectClass)
    {
        switch (defectClass)
        {
            case "Missing USB":
                return boxUSB.position;

            case "Missing CP2102":
                return boxCP2102.position;

            case "Missing ESP32":
                return boxESP32.position;

            case "Missing Capacitor":
                return boxCapacitor.position;

            case "Missing Resistor":
                return boxResistor.position;

            default:
                return boxOK.position;
        }
    }
}